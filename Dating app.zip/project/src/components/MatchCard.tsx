import React from 'react';
import { Music, Book, Camera, Coffee } from 'lucide-react';

interface Interest {
  icon: React.ReactNode;
  label: string;
}

interface MatchCardProps {
  name: string;
  age: number;
  compatibility: number;
  image: string;
  interests: string[];
}

export function MatchCard({ name, age, compatibility, image, interests }: MatchCardProps) {
  const interestIcons: Record<string, React.ReactNode> = {
    Music: <Music className="w-4 h-4" />,
    Reading: <Book className="w-4 h-4" />,
    Photography: <Camera className="w-4 h-4" />,
    Coffee: <Coffee className="w-4 h-4" />
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="relative">
        <img
          src={image}
          alt={name}
          className="w-full h-64 object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white text-xl font-semibold">{name}, {age}</h3>
            </div>
            <div className="bg-white rounded-full px-3 py-1">
              <span className="text-sm font-medium text-rose-500">{compatibility}% Match</span>
            </div>
          </div>
        </div>
      </div>
      <div className="p-4">
        <div className="flex flex-wrap gap-2">
          {interests.map((interest, index) => (
            <div key={index} className="flex items-center gap-1 bg-rose-50 text-rose-700 px-3 py-1 rounded-full text-sm">
              {interestIcons[interest]}
              <span>{interest}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}