import React from 'react';
import { Gamepad2 } from 'lucide-react';

export function InteractiveChallenge() {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-3 mb-4">
        <Gamepad2 className="w-6 h-6 text-rose-500" />
        <h2 className="text-xl font-semibold">Creative Challenge</h2>
      </div>
      <div className="bg-rose-50 rounded-lg p-4 mb-4">
        <p className="text-gray-800">
          Complete this story with your match:
        </p>
        <p className="mt-2 italic text-gray-600">
          "On a rainy Tuesday evening, they discovered something unexpected in their favorite coffee shop..."
        </p>
      </div>
      <textarea
        className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-transparent"
        rows={4}
        placeholder="Continue the story..."
      />
      <button className="mt-4 w-full bg-rose-500 text-white py-2 rounded-lg font-medium hover:bg-rose-600 transition">
        Share Response
      </button>
    </div>
  );
}