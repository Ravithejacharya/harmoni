import React from 'react';
import { MessageCircle } from 'lucide-react';

interface ChatPreview {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  timestamp: string;
  unread: boolean;
}

export function ChatList() {
  const chats: ChatPreview[] = [
    {
      id: '1',
      name: 'Sarah',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      lastMessage: 'That coffee shop sounds amazing!',
      timestamp: '2m ago',
      unread: true,
    },
    {
      id: '2',
      name: 'Michael',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      lastMessage: 'Would love to hear more about your photography',
      timestamp: '1h ago',
      unread: false,
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-4">
      <div className="flex items-center gap-2 mb-4">
        <MessageCircle className="w-6 h-6 text-rose-500" />
        <h2 className="text-xl font-semibold">Messages</h2>
      </div>
      <div className="space-y-2">
        {chats.map((chat) => (
          <div
            key={chat.id}
            className="flex items-center gap-3 p-3 rounded-lg hover:bg-rose-50 cursor-pointer transition"
          >
            <img
              src={chat.avatar}
              alt={chat.name}
              className="w-12 h-12 rounded-full"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">{chat.name}</h3>
                <span className="text-sm text-gray-500">{chat.timestamp}</span>
              </div>
              <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
            </div>
            {chat.unread && (
              <div className="w-2 h-2 bg-rose-500 rounded-full"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}