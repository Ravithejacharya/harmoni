import React, { useState, useRef, useEffect } from 'react';
import { Heart, Sparkles, MessageCircle } from 'lucide-react';
import { ProfileMenu } from './Profile/ProfileMenu';

export function Header() {
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="fixed top-0 w-full bg-white/80 backdrop-blur-md shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Heart className="w-8 h-8 text-rose-500" />
          <span className="text-2xl font-bold bg-gradient-to-r from-rose-500 to-purple-600 bg-clip-text text-transparent">
            Harmoni
          </span>
        </div>
        <nav className="flex items-center gap-6">
          <button className="p-2 hover:bg-rose-50 rounded-full">
            <Sparkles className="w-6 h-6 text-rose-500" />
          </button>
          <button className="p-2 hover:bg-rose-50 rounded-full">
            <MessageCircle className="w-6 h-6 text-rose-500" />
          </button>
          <div ref={menuRef} className="relative">
            <button
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face"
                alt="Profile"
                className="w-10 h-10 rounded-full border-2 border-rose-500"
              />
              {isProfileMenuOpen && (
                <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-rose-500 border-2 border-white rounded-full"></span>
              )}
            </button>
            <ProfileMenu
              isOpen={isProfileMenuOpen}
              onClose={() => setIsProfileMenuOpen(false)}
            />
          </div>
        </nav>
      </div>
    </header>
  );
}