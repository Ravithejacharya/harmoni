import React, { useState, useEffect } from 'react';
import { Heart, Share2, UserPlus, MapPin, Calendar, Edit } from 'lucide-react';
import { db, UserProfile as UserProfileType } from '../../lib/db';
import { EditProfile } from './EditProfile';

interface UserProfileProps {
  userId: string;
}

export function UserProfile({ userId }: UserProfileProps) {
  const [profile, setProfile] = useState<UserProfileType | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        // Query by userId instead of id
        const userProfile = await db.userProfiles.where('userId').equals(userId).first();
        
        if (!userProfile) {
          // Create a default profile if none exists
          const defaultProfile: UserProfileType = {
            userId,
            name: 'Sarah Anderson',
            age: 28,
            location: 'San Francisco, CA',
            bio: 'Photography enthusiast and coffee addict. Looking for someone to explore the city with! 📸 ☕',
            avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&h=500&fit=crop',
            images: [
              'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&h=500&fit=crop',
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&h=500&fit=crop',
            ],
            interests: ['Photography', 'Coffee', 'Hiking', 'Art'],
            joinDate: 'Joined September 2023',
            email: 'sarah@example.com',
            gender: 'Female',
            lookingFor: ['Male', 'Female'],
            preferences: {
              ageRange: [25, 35],
              distance: 25,
              showMe: true,
            },
          };
          const id = await db.userProfiles.add(defaultProfile);
          defaultProfile.id = id;
          setProfile(defaultProfile);
        } else {
          setProfile(userProfile);
        }
      } catch (error) {
        console.error('Error loading profile:', error);
      }
    };
    loadProfile();
  }, [userId]);

  if (!profile) {
    return <div>Loading...</div>;
  }

  if (isEditing) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <EditProfile
          profile={profile}
          onSave={() => setIsEditing(false)}
        />
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="relative">
        <img
          src={profile.avatar}
          alt={profile.name}
          className="w-full h-80 object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
          <h1 className="text-3xl font-bold text-white">{profile.name}, {profile.age}</h1>
          <div className="flex items-center gap-2 text-white/90 mt-2">
            <MapPin className="w-4 h-4" />
            <span>{profile.location}</span>
          </div>
        </div>
        <button
          onClick={() => setIsEditing(true)}
          className="absolute top-4 right-4 p-2 bg-white/90 rounded-full hover:bg-white transition"
        >
          <Edit className="w-5 h-5 text-gray-700" />
        </button>
      </div>

      <div className="p-6">
        <div className="flex gap-4 mb-6">
          <button className="flex-1 flex items-center justify-center gap-2 bg-rose-500 text-white py-2 rounded-lg hover:bg-rose-600 transition">
            <Heart className="w-5 h-5" />
            <span>Like</span>
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600 transition">
            <UserPlus className="w-5 h-5" />
            <span>Follow</span>
          </button>
          <button className="flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
            <Share2 className="w-5 h-5" />
          </button>
        </div>

        <p className="text-gray-700 mb-6">{profile.bio}</p>

        <div className="flex flex-wrap gap-2 mb-6">
          {profile.interests.map((interest, index) => (
            <span
              key={index}
              className="bg-rose-50 text-rose-700 px-3 py-1 rounded-full text-sm"
            >
              {interest}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-2 text-gray-500 text-sm">
          <Calendar className="w-4 h-4" />
          <span>{profile.joinDate}</span>
        </div>
      </div>
    </div>
  );
}