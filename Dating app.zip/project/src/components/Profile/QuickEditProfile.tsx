import React, { useState, useEffect } from 'react';
import { Camera } from 'lucide-react';
import { db, UserProfile } from '../../lib/db';

export function QuickEditProfile() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [status, setStatus] = useState('');

  useEffect(() => {
    const loadProfile = async () => {
      const userProfile = await db.userProfiles.where('userId').equals('current-user').first();
      setProfile(userProfile || null);
    };
    loadProfile();
  }, []);

  const handleStatusChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStatus(e.target.value);
  };

  const handleStatusSubmit = async () => {
    if (!profile?.id) return;
    
    await db.userProfiles.update(profile.id, {
      bio: status
    });
    
    setProfile(prev => prev ? { ...prev, bio: status } : null);
    setStatus('');
  };

  if (!profile) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative">
          <img
            src={profile.avatar}
            alt={profile.name}
            className="w-16 h-16 rounded-full object-cover"
          />
          <button className="absolute bottom-0 right-0 p-1 bg-white rounded-full shadow-md hover:bg-gray-50">
            <Camera className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        
        <div>
          <h3 className="font-semibold text-gray-900">{profile.name}</h3>
          <p className="text-sm text-gray-500">{profile.location}</p>
        </div>
      </div>

      <div className="relative">
        <input
          type="text"
          placeholder="Update your status..."
          value={status}
          onChange={handleStatusChange}
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-transparent"
        />
        {status && (
          <button
            onClick={handleStatusSubmit}
            className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1 bg-rose-500 text-white text-sm rounded-full hover:bg-rose-600"
          >
            Update
          </button>
        )}
      </div>
    </div>
  );
}