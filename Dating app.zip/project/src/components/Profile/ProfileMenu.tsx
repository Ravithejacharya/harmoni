import React from 'react';
import { User, Settings, LogOut } from 'lucide-react';
import { QuickEditProfile } from './QuickEditProfile';

interface ProfileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProfileMenu({ isOpen, onClose }: ProfileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="absolute right-0 top-16 w-80 bg-white rounded-xl shadow-lg p-4 z-50">
      <QuickEditProfile />
      
      <div className="mt-4 space-y-2">
        <button className="w-full flex items-center gap-3 px-4 py-2 text-left hover:bg-rose-50 rounded-lg transition">
          <User className="w-5 h-5 text-gray-600" />
          <span>View Full Profile</span>
        </button>
        <button className="w-full flex items-center gap-3 px-4 py-2 text-left hover:bg-rose-50 rounded-lg transition">
          <Settings className="w-5 h-5 text-gray-600" />
          <span>Settings</span>
        </button>
        <button className="w-full flex items-center gap-3 px-4 py-2 text-left text-red-600 hover:bg-red-50 rounded-lg transition">
          <LogOut className="w-5 h-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
}