import React, { useState } from 'react';
import { Camera, Save } from 'lucide-react';
import { db, UserProfile } from '../../lib/db';

interface EditProfileProps {
  profile: UserProfile;
  onSave: () => void;
}

export function EditProfile({ profile, onSave }: EditProfileProps) {
  const [formData, setFormData] = useState<Partial<UserProfile>>({
    name: profile.name,
    age: profile.age,
    location: profile.location,
    bio: profile.bio,
    interests: profile.interests,
    gender: profile.gender,
    lookingFor: profile.lookingFor,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (profile.id) {
      await db.userProfiles.update(profile.id, {
        ...formData,
        userId: profile.userId // Ensure userId is preserved
      });
    }
    onSave();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Profile Photo</label>
          <div className="mt-1 flex items-center gap-4">
            <img
              src={profile.avatar}
              alt={profile.name}
              className="w-20 h-20 rounded-full object-cover"
            />
            <button
              type="button"
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <Camera className="w-5 h-5" />
              <span>Change Photo</span>
            </button>
          </div>
        </div>

        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
          <input
            type="text"
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
          />
        </div>

        <div>
          <label htmlFor="age" className="block text-sm font-medium text-gray-700">Age</label>
          <input
            type="number"
            id="age"
            value={formData.age}
            onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
          />
        </div>

        <div>
          <label htmlFor="location" className="block text-sm font-medium text-gray-700">Location</label>
          <input
            type="text"
            id="location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
          />
        </div>

        <div>
          <label htmlFor="bio" className="block text-sm font-medium text-gray-700">Bio</label>
          <textarea
            id="bio"
            rows={4}
            value={formData.bio}
            onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-rose-500 focus:ring-rose-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Interests</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {formData.interests?.map((interest, index) => (
              <span
                key={index}
                className="bg-rose-50 text-rose-700 px-3 py-1 rounded-full text-sm"
              >
                {interest}
              </span>
            ))}
            <button
              type="button"
              className="px-3 py-1 border border-gray-300 rounded-full text-sm hover:bg-gray-50"
            >
              + Add Interest
            </button>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-4">
        <button
          type="button"
          onClick={onSave}
          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="flex items-center gap-2 px-4 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600"
        >
          <Save className="w-5 h-5" />
          <span>Save Changes</span>
        </button>
      </div>
    </form>
  );
}