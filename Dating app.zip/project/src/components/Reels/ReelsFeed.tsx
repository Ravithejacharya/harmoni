import React from 'react';
import { Play, Heart, MessageCircle, Share2 } from 'lucide-react';

interface Reel {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  video: string;
  likes: number;
  comments: number;
  description: string;
}

export function ReelsFeed() {
  const reels: Reel[] = [
    {
      id: '1',
      user: {
        name: 'Sarah',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      },
      video: 'https://example.com/video1.mp4',
      likes: 1234,
      comments: 89,
      description: 'Coffee tasting at my favorite spot ☕',
    },
    {
      id: '2',
      user: {
        name: 'Michael',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      },
      video: 'https://example.com/video2.mp4',
      likes: 2345,
      comments: 156,
      description: 'Weekend hiking adventure 🏔️',
    },
  ];

  return (
    <div className="space-y-6">
      {reels.map((reel) => (
        <div key={reel.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="flex items-center gap-3 p-4">
            <img
              src={reel.user.avatar}
              alt={reel.user.name}
              className="w-10 h-10 rounded-full"
            />
            <span className="font-medium">{reel.user.name}</span>
          </div>
          
          <div className="relative aspect-[9/16] bg-black">
            <div className="absolute inset-0 flex items-center justify-center">
              <Play className="w-16 h-16 text-white/80" />
            </div>
            
            <div className="absolute right-4 bottom-20 flex flex-col items-center gap-6">
              <button className="flex flex-col items-center text-white">
                <div className="bg-black/40 p-2 rounded-full">
                  <Heart className="w-6 h-6" />
                </div>
                <span className="text-sm">{reel.likes}</span>
              </button>
              
              <button className="flex flex-col items-center text-white">
                <div className="bg-black/40 p-2 rounded-full">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <span className="text-sm">{reel.comments}</span>
              </button>
              
              <button className="bg-black/40 p-2 rounded-full">
                <Share2 className="w-6 h-6 text-white" />
              </button>
            </div>
          </div>
          
          <div className="p-4">
            <p className="text-gray-700">{reel.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
}