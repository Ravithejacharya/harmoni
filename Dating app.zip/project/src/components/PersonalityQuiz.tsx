import React from 'react';
import { Brain } from 'lucide-react';

export function PersonalityQuiz() {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-3 mb-4">
        <Brain className="w-6 h-6 text-purple-600" />
        <h2 className="text-xl font-semibold">Daily Personality Quiz</h2>
      </div>
      <p className="text-gray-600 mb-4">
        Complete today's quiz to improve your matches!
      </p>
      <div className="space-y-4">
        <div className="p-4 border rounded-lg hover:border-purple-400 cursor-pointer transition">
          <p className="font-medium">How do you typically handle stress?</p>
          <div className="mt-3 space-y-2">
            {[
              "I exercise or do physical activities",
              "I talk to friends or family",
              "I practice meditation or mindfulness",
              "I focus on solving the problem methodically"
            ].map((option, index) => (
              <label key={index} className="flex items-center gap-2">
                <input type="radio" name="stress" className="text-purple-600" />
                <span className="text-gray-700">{option}</span>
              </label>
            ))}
          </div>
        </div>
      </div>
      <button className="mt-6 w-full bg-gradient-to-r from-rose-500 to-purple-600 text-white py-2 rounded-lg font-medium hover:opacity-90 transition">
        Continue Quiz
      </button>
    </div>
  );
}