import Dexie, { Table } from 'dexie';

export interface UserProfile {
  id?: number;
  userId: string;
  name: string;
  age: number;
  location: string;
  bio: string;
  avatar: string;
  images: string[];
  interests: string[];
  joinDate: string;
  email: string;
  gender: string;
  lookingFor: string[];
  preferences: {
    ageRange: [number, number];
    distance: number;
    showMe: boolean;
  };
}

export interface Match {
  id?: number;
  userId: string;
  matchedUserId: string;
  status: 'liked' | 'matched' | 'passed';
  timestamp: Date;
}

export class HarmoniDB extends Dexie {
  userProfiles!: Table<UserProfile>;
  matches!: Table<Match>;

  constructor() {
    super('harmoniDB');
    
    // Define schema with proper indexing
    this.version(2).stores({
      userProfiles: '++id, &userId, email', // Added unique index on userId
      matches: '++id, [userId+matchedUserId], status'
    });

    // Add hooks for data validation
    this.userProfiles.hook('creating', (primKey, obj) => {
      if (!obj.userId) throw new Error('userId is required');
      if (!obj.email) throw new Error('email is required');
      return obj;
    });

    this.matches.hook('creating', (primKey, obj) => {
      if (!obj.userId || !obj.matchedUserId) throw new Error('userId and matchedUserId are required');
      if (!obj.timestamp) obj.timestamp = new Date();
      return obj;
    });
  }

  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    return await this.userProfiles.where('userId').equals(userId).first();
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<number> {
    const profile = await this.getUserProfile(userId);
    if (!profile?.id) throw new Error('Profile not found');
    return await this.userProfiles.update(profile.id, updates);
  }

  async createUserProfile(profile: UserProfile): Promise<number> {
    return await this.userProfiles.add(profile);
  }
}

export const db = new HarmoniDB();