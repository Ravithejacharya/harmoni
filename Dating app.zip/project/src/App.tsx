import React, { useState } from 'react';
import { Header } from './components/Header';
import { PersonalityQuiz } from './components/PersonalityQuiz';
import { InteractiveChallenge } from './components/InteractiveChallenge';
import { MatchCard } from './components/MatchCard';
import { ChatList } from './components/Chat/ChatList';
import { UserProfile } from './components/Profile/UserProfile';
import { ReelsFeed } from './components/Reels/ReelsFeed';
import { LayoutGrid, MessageCircle, Film, Users } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState<'discover' | 'chat' | 'reels' | 'profile'>('discover');
  
  const matches = [
    {
      name: "Sarah",
      age: 28,
      compatibility: 95,
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&h=500&fit=crop",
      interests: ["Music", "Photography", "Coffee"]
    },
    {
      name: "Michael",
      age: 31,
      compatibility: 92,
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&h=500&fit=crop",
      interests: ["Reading", "Music", "Coffee"]
    }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'discover':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <h1 className="text-3xl font-bold text-gray-900">Your Matches</h1>
              <div className="grid sm:grid-cols-2 gap-6">
                {matches.map((match, index) => (
                  <MatchCard key={index} {...match} />
                ))}
              </div>
            </div>
            <div className="space-y-6">
              <PersonalityQuiz />
              <InteractiveChallenge />
            </div>
          </div>
        );
      case 'chat':
        return <ChatList />;
      case 'reels':
        return <ReelsFeed />;
      case 'profile':
        return <UserProfile userId="current-user" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-7xl mx-auto px-4 pt-20 pb-20">
        {renderContent()}
      </main>
      
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-around py-3">
            <button
              onClick={() => setActiveTab('discover')}
              className={`flex flex-col items-center gap-1 ${
                activeTab === 'discover' ? 'text-rose-500' : 'text-gray-500'
              }`}
            >
              <LayoutGrid className="w-6 h-6" />
              <span className="text-xs">Discover</span>
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex flex-col items-center gap-1 ${
                activeTab === 'chat' ? 'text-rose-500' : 'text-gray-500'
              }`}
            >
              <MessageCircle className="w-6 h-6" />
              <span className="text-xs">Chat</span>
            </button>
            <button
              onClick={() => setActiveTab('reels')}
              className={`flex flex-col items-center gap-1 ${
                activeTab === 'reels' ? 'text-rose-500' : 'text-gray-500'
              }`}
            >
              <Film className="w-6 h-6" />
              <span className="text-xs">Reels</span>
            </button>
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center gap-1 ${
                activeTab === 'profile' ? 'text-rose-500' : 'text-gray-500'
              }`}
            >
              <Users className="w-6 h-6" />
              <span className="text-xs">Profile</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default App;